import open3d as o3d
import transforms3d as t3d
import numpy as np
import scipy
import matplotlib.pyplot as plt
import matplotlib
import matplotlib.cm as cm


def load_mesh(file_path) -> o3d.geometry.TriangleMesh:
    mesh = o3d.io.read_triangle_mesh(file_path)
    return mesh


def sphere_projection(
    points: np.ndarray,
    view_position: np.ndarray,
    radius: float,
) -> np.ndarray:
    """do the sphere projection with respect to the sphere of radius centered at view_position.

    Args:
        points (np.ndarray): 3xN array of points to be projected
        view_position (np.ndarray): 3-element vector of the view position
        radius (float): radius of the sphere

    Returns:
        np.ndarray: 3xN array of projected points
    """
    x = points - view_position.reshape(3, 1)
    norm = np.linalg.norm(x, axis=0, keepdims=True)
    v = x / norm
    x = x + 2 * (radius - norm) * v
    return x


def convex_hull(points: np.ndarray) -> np.ndarray:
    """compute the convex hull of points

    Args:
        points (np.ndarray): 3xN array of points

    Returns:
        np.ndarray: indices of points that forms the convex hull
    """
    qhull = scipy.spatial.ConvexHull(points.T)
    return np.array(qhull.vertices)


def hidden_point_removal(points: np.ndarray, view_position: np.ndarray, radius: float = None) -> np.ndarray:
    """remove hidden points from the points with respect to the view position and the sphere of radius.

    Args:
        points (np.ndarray): 3xN array of points to be projected
        view_position (np.ndarray): 3-element vector of the view position
        radius (float): radius of the sphere

    Returns:
        np.ndarray: indices of the visible points
    """
    if radius is None:
        radius = np.linalg.norm(points - view_position.reshape(3, 1), axis=0).max() * 10.0
    points_sp = sphere_projection(points, view_position, radius)
    points_sp = np.insert(points_sp, points_sp.shape[1], 0, axis=1)
    indices = convex_hull(points_sp)
    mask = indices != points_sp.shape[1] - 1
    indices = indices[mask]
    return indices


def as_point_cloud(points: np.ndarray, color: np.ndarray = None) -> o3d.geometry.PointCloud:
    pc = o3d.geometry.PointCloud()
    pc.points.extend(points.T)
    if color is not None:
        pc.paint_uniform_color(color)
    return pc


def create_axis_mesh(scale: float = 1.0, pose: np.ndarray = None) -> o3d.geometry.TriangleMesh:
    mesh = o3d.geometry.TriangleMesh()
    cyliner_radius = 0.0025 * scale
    cone_radius = 0.0075 * scale
    cone_height = 0.04 * scale
    axis_length = scale - cone_height

    axes = [
        o3d.geometry.TriangleMesh.create_arrow(cyliner_radius, cone_radius, axis_length, cone_height) for _ in range(3)
    ]
    axes[0] = (
        axes[0]
        .rotate(t3d.euler.euler2mat(0, np.pi / 2, 0), np.array([0.0, 0.0, 0.0]))
        .paint_uniform_color(np.array([1.0, 0.0, 0.0]))
    )
    axes[1] = (
        axes[1]
        .rotate(t3d.euler.euler2mat(-np.pi / 2, 0, 0), np.array([0.0, 0.0, 0.0]))
        .paint_uniform_color(np.array([0.0, 1.0, 0.0]))
    )
    axes[2] = axes[2].paint_uniform_color(np.array([0.0, 0.0, 1.0]))
    mesh += axes[0]
    mesh += axes[1]
    mesh += axes[2]
    if pose is not None:
        mesh = mesh.transform(pose)
    return mesh


class App:
    def __init__(self, mesh_file: str, mesh_is_obj: bool = False):
        self.scene_mesh = load_mesh(mesh_file)
        max_bound = self.scene_mesh.get_max_bound()
        min_bound = self.scene_mesh.get_min_bound()
        size = np.max(max_bound - min_bound)
        center = (max_bound + min_bound) / 2.0
        self.xyz = center
        if mesh_is_obj:
            self.xyz += np.array([1.2 * size, 0.0, 0.0])
        self.rpy = np.zeros((3,))
        self.azimuth_min = -np.pi
        self.azimuth_max = np.pi
        self.elevation_min = -np.pi / 12  # 15 degrees
        self.elevation_max = np.pi / 12
        self.num_azimuth_lines = 360
        self.num_elevation_lines = 31

        self.pos_mesh = o3d.geometry.TriangleMesh.create_sphere(radius=0.05 * size)
        self.pos_mesh.paint_uniform_color(np.array([0.0, 0.0, 1.0]))
        self.pos_mesh.translate(self.xyz)

        np.random.seed(0)  # adjust the seed to get different results
        deviate = np.random.rand(3) * size * 0.5
        self.xyz_new = self.xyz + deviate

        print(f"Original view position: {self.xyz}")
        print(f"New view position: {self.xyz_new}")

        self.pos_mesh_new = o3d.geometry.TriangleMesh.create_sphere(radius=0.05 * size)
        self.pos_mesh_new.paint_uniform_color(np.array([0.0, 1.0, 0.0]))
        self.pos_mesh_new.translate(self.xyz_new)

        self.ray_casting_scene = o3d.t.geometry.RaycastingScene()
        self.ray_casting_scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(self.scene_mesh))

    @property
    def azimuth_angles(self) -> np.ndarray:
        return np.linspace(self.azimuth_min, self.azimuth_max, self.num_azimuth_lines, endpoint=False)

    @property
    def elevation_angles(self) -> np.ndarray:
        return np.linspace(self.elevation_min, self.elevation_max, self.num_elevation_lines, endpoint=True)

    @property
    def ray_directions_body(self) -> np.ndarray:
        ga, ge = np.meshgrid(self.azimuth_angles, self.elevation_angles, indexing="ij")
        ga = ga.flatten()
        ge = ge.flatten()
        dirs = np.empty([3, ga.size])
        ce = np.cos(ge)
        dirs[0] = ce * np.cos(ga)
        dirs[1] = ce * np.sin(ga)
        dirs[2] = np.sin(ge)
        return dirs

    @property
    def ray_directions_world(self) -> np.ndarray:
        rot = t3d.euler.euler2mat(self.rpy[0], self.rpy[1], self.rpy[2])
        dirs = rot @ self.ray_directions_body  # (3, N)
        return dirs

    def cast_rays(self) -> dict:
        ray_dirs = self.ray_directions_world
        ray_pos = np.tile(self.xyz[np.newaxis], reps=(self.num_azimuth_lines * self.num_elevation_lines, 1))
        rays = np.hstack([ray_pos, ray_dirs.T])  # (N, 6)
        rays = o3d.core.Tensor(rays, dtype=o3d.core.Dtype.Float32)
        results = self.ray_casting_scene.cast_rays(rays)
        t_hit = results["t_hit"].numpy()
        mask = ~np.isinf(t_hit)
        t_hit = t_hit[mask].reshape((1, -1))
        ray_dirs = ray_dirs[:, mask]  # (3, N)
        end_pts = self.xyz[:, np.newaxis] + t_hit * ray_dirs  # (3, N)
        return dict(pos=self.xyz, dirs=ray_dirs, end_pts=end_pts)

    def run(self):
        # generate the lidar scan
        ray_dict = self.cast_rays()

        pc_points = as_point_cloud(ray_dict["end_pts"], color=np.array([0.0, 0.0, 1.0]))

        indices = hidden_point_removal(ray_dict["end_pts"], self.xyz_new)
        for i in indices:  # paint the points that are visible from the new view position to green
            pc_points.colors[i] = np.array([0.0, 1.0, 0.0])

        # visualize the results
        o3d.visualization.draw_geometries([self.scene_mesh, pc_points, self.pos_mesh, self.pos_mesh_new])


def main():
    app = App("bunny.ply", mesh_is_obj=True)
    # app = App("house_expo_room_1451.ply", mesh_is_obj=False)
    app.run()


if __name__ == "__main__":
    main()
