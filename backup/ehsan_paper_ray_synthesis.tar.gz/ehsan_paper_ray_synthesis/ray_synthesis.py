import open3d as o3d
import transforms3d as t3d
import numpy as np
import scipy
import matplotlib.pyplot as plt
import matplotlib
import matplotlib.cm as cm


def load_mesh(file_path) -> o3d.geometry.TriangleMesh:
    mesh = o3d.io.read_triangle_mesh(file_path)
    return mesh


def sphere_projection(
    points: np.ndarray,
    hit_point_index: int,
    view_direction: np.ndarray,
) -> np.ndarray:
    """do the sphere projection according to Ehsan's paper

    Args:
        points (np.ndarray): 3xN array of points
        hit_point (np.ndarray): 3-element vector of the hit point
        view_position (np.ndarray): 3-element vector of the view position
        view_direction (np.ndarray): 3-element vector of the view direction

    Returns:
        np.ndarray: 3xN array of the points projected onto the unit sphere
    """

    # 1. translate the hit point to the origin
    # 2. scale and rotate the scene so the view position is at (0, 0, 1), the view direction is (0, 0, -1)
    # 3. project the points onto the unit sphere
    hit_point = points[:, hit_point_index]
    trans1 = np.eye(4)
    trans1[:3, 3] = -hit_point

    axis = np.cross(-view_direction, np.array([0.0, 0.0, 1.0]))
    axis /= np.linalg.norm(axis)
    angle = np.arccos(np.dot(-view_direction, np.array([0.0, 0.0, 1.0])))
    trans2 = np.eye(4)
    trans2[:3, :3] = t3d.axangles.axangle2mat(axis, angle)

    assert np.isclose((trans2[:3, :3] @ -view_direction)[2], 1.0)

    trans = trans2 @ trans1

    points_homo = np.insert(points, 3, 1, axis=0)  # (4, N)
    points_homo = trans @ points_homo
    points: np.ndarray = points_homo[:3]

    indices = [i for i in range(points.shape[1]) if i != hit_point_index]
    rhos = np.linalg.norm(points[:, indices], ord=2, axis=0, keepdims=True)  # (N-1, )
    points[:, indices] /= rhos  # points are on the unit sphere now
    points[:, hit_point_index] = 0

    return trans, points


def plane_projection(points: np.ndarray) -> np.ndarray:
    """project points with respect to the pin-hole at (0, 0, 1) to the plane at z=0 with normal (0, 0, 1)

    Args:
        points (np.ndarray): 3xN array of points to project

    Returns:
        np.ndarray: 3xN array of the projected points
    """
    assert not np.any(np.isnan(points) | np.isinf(points))
    d = 1 - points[2]
    xy = np.array([points[0] / d, points[1] / d])
    assert not np.any(np.isnan(xy) | np.isinf(xy))
    xyz = np.insert(xy, 2, 0, axis=0)
    return xyz


def convex_hull(points: np.ndarray) -> np.ndarray:
    """compute the convex hull of points

    Args:
        points (np.ndarray): 3xN array of points

    Returns:
        np.ndarray: indices of points that forms the convex hull
    """
    qhull = scipy.spatial.ConvexHull(points.T)
    return np.array(qhull.vertices)


def as_point_cloud(points: np.ndarray, color: np.ndarray = None) -> o3d.geometry.PointCloud:
    pc = o3d.geometry.PointCloud()
    pc.points.extend(points.T)
    if color is not None:
        pc.paint_uniform_color(color)
    return pc


def create_axis_mesh(scale: float = 1.0, pose: np.ndarray = None) -> o3d.geometry.TriangleMesh:
    mesh = o3d.geometry.TriangleMesh()
    cyliner_radius = 0.0025 * scale
    cone_radius = 0.0075 * scale
    cone_height = 0.04 * scale
    axis_length = scale - cone_height

    axes = [
        o3d.geometry.TriangleMesh.create_arrow(cyliner_radius, cone_radius, axis_length, cone_height) for _ in range(3)
    ]
    axes[0] = (
        axes[0]
        .rotate(t3d.euler.euler2mat(0, np.pi / 2, 0), np.array([0.0, 0.0, 0.0]))
        .paint_uniform_color(np.array([1.0, 0.0, 0.0]))
    )
    axes[1] = (
        axes[1]
        .rotate(t3d.euler.euler2mat(-np.pi / 2, 0, 0), np.array([0.0, 0.0, 0.0]))
        .paint_uniform_color(np.array([0.0, 1.0, 0.0]))
    )
    axes[2] = axes[2].paint_uniform_color(np.array([0.0, 0.0, 1.0]))
    mesh += axes[0]
    mesh += axes[1]
    mesh += axes[2]
    if pose is not None:
        mesh = mesh.transform(pose)
    return mesh


class App:
    def __init__(self, mesh_file, mesh_is_obj: bool = False):
        self.scene_mesh = load_mesh(mesh_file)
        max_bound = self.scene_mesh.get_max_bound()
        min_bound = self.scene_mesh.get_min_bound()
        size = np.max(max_bound - min_bound)
        center = (max_bound + min_bound) / 2.0
        self.xyz = center
        if mesh_is_obj:
            self.xyz += np.array([1.2 * size, 0.0, 0.0])
        self.rpy = np.zeros((3,))
        self.azimuth_min = -np.pi
        self.azimuth_max = np.pi
        self.elevation_min = -np.pi / 12  # 15 degrees
        self.elevation_max = np.pi / 12
        self.num_azimuth_lines = 360
        self.num_elevation_lines = 31

        self.axes_mesh = create_axis_mesh(size)

        self.pos_mesh = o3d.geometry.TriangleMesh.create_sphere(radius=0.025 * size)
        self.pos_mesh.paint_uniform_color(np.array([0.0, 0.0, 1.0]))
        self.pos_mesh.translate(self.xyz)

        self.ray_casting_scene = o3d.t.geometry.RaycastingScene()
        self.ray_casting_scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(self.scene_mesh))

        self.o3d_rays = o3d.geometry.LineSet()

    @property
    def azimuth_angles(self) -> np.ndarray:
        return np.linspace(self.azimuth_min, self.azimuth_max, self.num_azimuth_lines, endpoint=False)

    @property
    def elevation_angles(self) -> np.ndarray:
        return np.linspace(self.elevation_min, self.elevation_max, self.num_elevation_lines, endpoint=True)

    @property
    def ray_directions_body(self) -> np.ndarray:
        ga, ge = np.meshgrid(self.azimuth_angles, self.elevation_angles, indexing="ij")
        ga = ga.flatten()
        ge = ge.flatten()
        dirs = np.empty([3, ga.size])
        ce = np.cos(ge)
        dirs[0] = ce * np.cos(ga)
        dirs[1] = ce * np.sin(ga)
        dirs[2] = np.sin(ge)
        return dirs

    @property
    def ray_directions_world(self) -> np.ndarray:
        rot = t3d.euler.euler2mat(self.rpy[0], self.rpy[1], self.rpy[2])
        dirs = rot @ self.ray_directions_body  # (3, N)
        return dirs

    def cast_rays(self) -> dict:
        ray_dirs = self.ray_directions_world
        ray_pos = np.tile(self.xyz[np.newaxis], reps=(self.num_azimuth_lines * self.num_elevation_lines, 1))
        rays = np.hstack([ray_pos, ray_dirs.T])  # (N, 6)
        rays = o3d.core.Tensor(rays, dtype=o3d.core.Dtype.Float32)
        results = self.ray_casting_scene.cast_rays(rays)
        t_hit = results["t_hit"].numpy()
        mask = ~np.isinf(t_hit)
        t_hit = t_hit[mask].reshape((1, -1))
        ray_dirs = ray_dirs[:, mask]  # (3, N)
        end_pts = self.xyz[:, np.newaxis] + t_hit * ray_dirs  # (3, N)
        return dict(pos=self.xyz, dirs=ray_dirs, end_pts=end_pts)

    def update_line_set(self, ray_dict: dict, indices: list = None) -> None:
        self.o3d_rays.clear()
        self.o3d_rays.points.append(ray_dict["pos"])
        self.o3d_rays.points.extend(ray_dict["end_pts"].T)
        n = ray_dict["end_pts"].shape[1]
        if indices is not None:
            self.o3d_rays.lines.extend([[0, x + 1] for x in indices])
        else:
            self.o3d_rays.lines.extend([[0, x + 1] for x in range(n)])
        self.o3d_rays.paint_uniform_color(np.array([1.0, 0.0, 0.0]))

    def run(self):
        # generate a lidar scan
        ray_dict = self.cast_rays()
        np.random.seed(2)  # adjust the seed to see different results
        n = np.random.randint(ray_dict["end_pts"].shape[1])  # pick a ray's end point as the known hit point
        self.update_line_set(ray_dict, [n])  # update the line set that represents the rays

        trans_sp, points_sp = sphere_projection(
            points=ray_dict["end_pts"],
            hit_point_index=n,
            view_direction=ray_dict["dirs"][:, n],
        )

        # do the plane projection described in Lemma 5.
        mask = (ray_dict["dirs"].T @ ray_dict["dirs"][:, [n]]).flatten() > 0  # mask of points that are in front of the view position
        points_plane = plane_projection(points_sp[:, mask])
        # indices of the points that form the convex hull
        indices = convex_hull(points_plane[:2])  # indices of points adjacent to e3
        indices2 = np.argwhere(mask).flatten()[indices]

        # display the plane projection in 2d
        plt.scatter(points_plane[0], points_plane[1])
        plt.scatter(points_plane[0, indices], points_plane[1, indices])
        plt.grid(True)
        plt.axis("equal")
        plt.show()

        # display points in a frame with the origin at the hit point, z-axis pointing to the view position at (0, 0, 1)
        pc_points_plane = as_point_cloud(points_plane, color=np.array([0.0, 1.0, 1.0]))  # cyan
        pc_points_sp = as_point_cloud(points_sp, color=np.array([1.0, 0.0, 1.0]))  # magenta
        pc_points_sp.points.append(np.zeros((3,)))
        pc_points_sp.colors.append(np.array([1.0, 0.0, 0.0]))  # hit point is red
        pc_points_sp.points.append(np.array([0.0, 0.0, 1.0]))
        pc_points_sp.colors.append(np.array([0.0, 0.0, 1.0]))  # view position is blue
        # color other points based on their distance to the hit point
        distances = np.linalg.norm(ray_dict["end_pts"] - ray_dict["end_pts"][:, [n]], axis=0)
        norm = matplotlib.colors.Normalize(vmin=np.min(distances), vmax=np.max(distances))
        m = cm.ScalarMappable(norm=norm, cmap=cm.hot)
        for i, dist in enumerate(distances):
            pc_points_sp.colors[i] = m.to_rgba(dist)[:3]
        for i in np.argwhere(~mask).flatten():
            pc_points_sp.colors[i] = [0.0, 0.0, 0.0]
        # however, color the points that form the convex hull to green
        for i in indices2:
            pc_points_sp.colors[i] = [0.0, 1.0, 0.0]
        o3d.visualization.draw_geometries([pc_points_plane, pc_points_sp, create_axis_mesh()])  # display

        # display points and the mesh in the world frame
        points_sp_inv = np.linalg.inv(trans_sp) @ np.insert(points_sp, 3, 1, axis=0)
        points_sp_inv = points_sp_inv[:3]
        pc_points_sp_inv = as_point_cloud(points_sp_inv, color=np.array([0.0, 0.0, 1.0]))
        points_plane_inv = np.linalg.inv(trans_sp) @ np.insert(points_plane, 3, 1, axis=0)
        points_plane_inv = points_plane_inv[:3]
        pc_points_plane_inv = as_point_cloud(points_plane_inv, color=np.array([0.0, 1.0, 1.0]))
        # original lidar scan
        pc_points_org = as_point_cloud(ray_dict["end_pts"], color=np.array([0.5, 0.0, 1.0]))
        for i in np.argwhere(~mask).flatten():
            pc_points_sp_inv.colors[i] = [0.0, 0.0, 0.0]
            pc_points_org.colors[i] = [0.0, 0.0, 0.0]  # points that are not considered
        for i in indices2:
            if i == n:
                continue
            pc_points_org.colors[i] = [0.0, 1.0, 0.0]  # points that form the convex hull are green
        pc_points_org.colors[n] = [0.5, 1.0, 1.0]  # hit point is red
        o3d.visualization.draw_geometries(
            [
                # self.scene_mesh,
                self.pos_mesh,
                self.o3d_rays,
                pc_points_sp_inv,
                pc_points_plane_inv,
                pc_points_org,
                create_axis_mesh(scale=0.1),
            ]
        )


def main():
    # app = App("bunny.ply", mesh_is_obj=True)
    app = App("house_expo_room_1451.ply", mesh_is_obj=False)
    app.run()


if __name__ == "__main__":
    main()
